/* eslint-disable quotes */

const eslint = require('@eslint/js');

/**
 * @type {import("eslint").Linter.ConfigData[]}
 */

const config = [
    eslint.configs.recommended,                                                 // Apply ESLint's recommended rules
    {
        rules: {
            "arrow-spacing": ["error", { "before": true, "after": true }],      // Spacing around arrow functions
            "no-cond-assign": "error",                                          // Disallow assignment in conditional expressions (if(x=0){})
            "no-dupe-args": "error",                                            // Disallow duplicate arguments in function definitions
            "no-dupe-else-if": "error",                                         // Disallow duplicate conditions in if-else-if chains
            "no-dupe-keys": "error",                                            // Disallow duplicate keys in object literals
            "no-extra-semi": "error",                                           // Disallow unnecessary semicolons (;;)
            "no-multi-spaces": ["error", { "ignoreEOLComments": true }],        // No multiple spaces
            "no-multiple-empty-lines": ["error", { "max": 2 }],                 // Limit empty lines
            "no-trailing-spaces": "error",                                      // No trailing whitespace
            "no-undef": "error",                                                // Disallow use of undeclared variables
            "no-var": "error",                                                  // Prevent var usage
            "object-curly-spacing": ["error", "always"],                        // Spaces inside curly braces
            "prefer-const": "off",                                              // Suggest const when variable is never reassigned
            "quotes": [                                                         // Single quotes
                "warn", "single", { "avoidEscape": true, "allowTemplateLiterals": true }
            ],
            "semi": "error",                                                    // Require semicolons at the end of statements
            "space-before-blocks": "error",                                     // Space before blocks
            "space-infix-ops": "error",                                         // Space around operators
            "use-isnan": "error",                                               // Require use of isNaN() when checking for NaN
            "no-constant-condition": "off",                                     // Disallow constant expressions in conditions
            "no-inner-declarations": "warn",                                    // Disallow function or variable declarations in nested blocks
            "no-unused-vars": ["warn",                                          // Handle unused variables
                {
                    "args": "none",                                             // Ignore unused function arguments
                    "varsIgnorePattern": "^_$",                                 // Ignore variables named _
                    "caughtErrorsIgnorePattern": "^_"                           // Ignore _ for catch blocks
                }
            ]
        },
        languageOptions: {
            ecmaVersion: 2022,                                                  // Use ECMAScript 2022
            sourceType: "script",                                               // Use CommonJS only
            globals: {
                Buffer: "readonly",
                BigInt: "readonly",
                Blob: "readonly",
                global: "readonly",
                exports: "readonly",
                document: "readonly",
                process: "readonly",
                require: "readonly",
                module: "readonly",
                console: "readonly",
                __dirname: "readonly",
                __filename: "readonly",
                setTimeout: "readonly",
                setInterval: "readonly",
                clearInterval: "readonly",
                clearTimeout: "readonly",
                URL: "readonly",
                URLSearchParams: "readonly",
                Uint8Array: "readonly",
                window: "readonly",
                Node: "readonly",
                NodeFilter: "readonly",
            }
        },
        ignores: ["dist/", "node_modules/", "*.min.js"]                         // Ignore specific paths
    }
];

module.exports = config;