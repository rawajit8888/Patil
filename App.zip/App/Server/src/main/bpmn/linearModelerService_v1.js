const os = require('os');
const xml2js = require('xml2js');

const { constants, config, cacheService, bpmnService, processDefinition } = global.modules;

async function generateBPMN(params) {
    let { modelType, fileName, definitionData, doNotRenderGroups, noAutoNext } = params;
    let maxGroupWidth = params.maxGroupWidth || 1500;
    let groupPaddingX = 15;
    let groupPaddingY = 75;
    let groupMarginX = 20;
    let groupMarginY = 20;
    let taskMarginX = 80;
    let marginY = 250;
    let arrowYMarginY = 60;
    let lineGapY = 40;

    let rslt;
    let bpmnElementDefaultSize = constants.bpmnElementDefaultSize;

    function getBounds(element) {
        let { x, y } = element.diaBounds;
        let { width, height } = element.extraInfo;

        let xAxis = { start: x, middle: x + (width / 2), end: x + width };
        let yAxis = { start: y, middle: y + (height / 2), end: y + height };
        return { x: xAxis, y: yAxis };
    }

    function getArrowPoints(boundsIn, boundsOut, isInSequence) {
        let points = [];
        if (boundsIn.y.middle == boundsOut.y.middle) {
            // Both elements are in same horizontal area.
            if (isInSequence) {
                // Both elements are next to each other. Simple line.
                points.push({ x: boundsIn.x.end, y: boundsIn.y.middle });
                points.push({ x: boundsOut.x.start, y: boundsOut.y.middle });
            } else {
                // Both elements are not next to each other. Line will go under tasks.
                points.push({ x: boundsIn.x.middle, y: boundsIn.y.end });
                points.push({ x: boundsIn.x.middle, y: boundsIn.y.end + arrowYMarginY });
                points.push({ x: boundsOut.x.middle, y: boundsIn.y.end + arrowYMarginY });
                points.push({ x: boundsOut.x.middle, y: boundsOut.y.end });
            }
        } else {
            // Both elements are in different horizontal area.
            let lastPoint;
            if (boundsIn.y.middle < boundsOut.y.middle) {
                points.push({ x: boundsIn.x.middle, y: boundsIn.y.end });
                lastPoint = { x: boundsIn.x.middle, y: boundsIn.y.end + arrowYMarginY };
                points.push(lastPoint);
            } else {
                points.push({ x: boundsIn.x.middle, y: boundsIn.y.start });
                lastPoint = { x: boundsIn.x.middle, y: boundsIn.y.start - arrowYMarginY };
                points.push(lastPoint);
            }
            points.push({ x: boundsOut.x.middle, y: lastPoint.y });

            if (boundsIn.y.middle < boundsOut.y.middle) {
                points.push({ x: boundsOut.x.middle, y: boundsOut.y.start });
            } else {
                points.push({ x: boundsOut.x.middle, y: boundsOut.y.end });
            }
        }
        return points;
    }

    let elementMap = {};

    rslt = await cacheService.get(constants.tableNames.Field);
    if (rslt.rc != 0) return rslt;
    let fieldMap = rslt.data;
    let fieldNameMap = {};
    for (let field of Object.values(fieldMap)) {
        fieldNameMap[field.id] = field;
    }

    let processEle = definitionData.process;
    let processElement = { typ: 'bpmn:process', isExecutable: true, ...processEle };
    elementMap[processEle.id] = processElement;

    let eleBounds = {};
    let groupPosArr = [];

    if (definitionData.start != null) {
        definitionData.groups[0].steps.unshift({ type: 'start', ...definitionData.start });
    }

    if (definitionData.end != null) {
        definitionData.groups[definitionData.groups.length - 1].steps.push({ type: 'end', ...definitionData.end });
    }

    for (let grp = 0; grp < definitionData.groups.length; grp++) {
        let group = definitionData.groups[grp];
        let steps = group.steps;

        let groupWidth = 0;
        let groupHeight = 0;
        let eleX = 0;
        let eleY = 0;

        let nextLvl;
        let currLvl;

        for (let i = 0; i < steps.length; i++) {
            let step = steps[i];
            currLvl = step.lvl;
            nextLvl = null;
            if (i < steps.length - 1) {
                nextLvl = steps[i + 1].lvl;
            }
            let { type } = step;
            let eleBound = {};

            let extraLen = 0;
            if (i > 0) {
                let prevStep = steps[i - 1];
                if (prevStep.type == 'gateway') {
                    let flowLen = 0;
                    for (let flow of prevStep.flows) {
                        if (flow.name != null && flow.name.length > flowLen) flowLen = flow.name.length;
                    }
                    extraLen = flowLen * 1.5;
                }
            }

            let marginX = taskMarginX + extraLen;
            if (type == 'task') {
                eleBound.x = eleX + marginX;
                eleBound.y = eleY;
                eleBound.width = bpmnElementDefaultSize.TaskWidth;
                eleBound.height = bpmnElementDefaultSize.TaskHeight;
            } else if (type == 'gateway') {
                eleBound.x = eleX + marginX;
                eleBound.y = eleY + (bpmnElementDefaultSize.TaskHeight / 2) - (bpmnElementDefaultSize.GatewayHeight / 2);
                eleBound.width = bpmnElementDefaultSize.GatewayWidth;
                eleBound.height = bpmnElementDefaultSize.GatewayHeight;
            } else if (type == 'start') {
                eleBound.x = eleX;
                eleBound.y = eleY + (bpmnElementDefaultSize.TaskHeight / 2) - (bpmnElementDefaultSize.StartEventHeight / 2);
                eleBound.width = bpmnElementDefaultSize.StartEventWidth;
                eleBound.height = bpmnElementDefaultSize.StartEventHeight;
            } else if (type == 'end') {
                eleBound.x = eleX + marginX;
                eleBound.y = eleY + (bpmnElementDefaultSize.TaskHeight / 2) - (bpmnElementDefaultSize.EndEventHeight / 2);
                eleBound.width = bpmnElementDefaultSize.EndEventWidth;
                eleBound.height = bpmnElementDefaultSize.EndEventHeight;
            }
            eleBounds[step.id] = eleBound;
            eleX = eleBound.x + eleBound.width;

            let lvlBreak = nextLvl != null && currLvl != null && currLvl != nextLvl;

            if (eleX > maxGroupWidth || lvlBreak == true) {
                eleX = 0;
                eleY += marginY;
            }

            let grpWidth = eleBound.x + eleBound.width;
            groupWidth = Math.max(groupWidth, grpWidth);

            let grpHeight = eleBound.y + eleBound.height;
            groupHeight = Math.max(groupHeight, grpHeight);
        }

        let groupPos = { name: group.name, width: groupWidth + taskMarginX + (groupPaddingX * 3), height: groupHeight + (groupPaddingY * 2) };
        if (grp == 0) {
            groupPos.x = groupMarginX;
            groupPos.y = groupMarginY;
        }
        groupPosArr.push(groupPos);
    }

    for (let grp = 1; grp < definitionData.groups.length; grp++) {
        let groupPos = groupPosArr[grp];
        let prevGroupPos = groupPosArr[grp - 1];
        let x = prevGroupPos.x + prevGroupPos.width + groupMarginX;
        let y = prevGroupPos.y;
        if (x + groupPos.width > maxGroupWidth) {
            x = 0;
            y += prevGroupPos.height + groupMarginY;
        }
        groupPos.x = x + groupMarginX;
        groupPos.y = y;
    }

    for (let grp = 0; grp < definitionData.groups.length; grp++) {
        let group = definitionData.groups[grp];
        let groupPos = groupPosArr[grp];
        let steps = group.steps;

        for (let i = 0; i < steps.length; i++) {
            let step = steps[i];
            let { type } = step;

            let element;

            let stepData = { ...step };
            delete stepData.flows;
            delete stepData.next;
            delete stepData.type;
            delete stepData.lvl;

            if (type == 'task') {
                element = { typ: constants.bpmnNodeType.Task, ...stepData, extraInfo: { ...step } };
            } else if (type == 'gateway') {
                element = { typ: constants.bpmnNodeType.ExclusiveGateway, ...stepData, extraInfo: { ...step } };
            } else if (type == 'start') {
                element = { typ: constants.bpmnNodeType.StartEvent, ...stepData, extraInfo: { ...step } };
            } else if (type == 'end') {
                element = { typ: constants.bpmnNodeType.EndEvent, ...stepData, extraInfo: { ...step } };
            }

            let eleBound = eleBounds[step.id];
            let x = eleBound.x + groupPos.x + groupPaddingX;
            let y = eleBound.y + groupPos.y + groupPaddingY;

            element.diaBounds = step.diaBounds || { x: x, y: y };
            element.extraInfo.width = eleBound.width;
            element.extraInfo.height = eleBound.height;
            elementMap[step.id] = element;
        }
    }

    let sequenceFlowMap = {};
    let ids = Object.keys(elementMap);

    let flowNo = 0;
    for (let i = 1; i < ids.length - 1; i++) {
        let id = ids[i];
        let element = elementMap[id];

        let outgoing = [];

        let nextSteps;
        let nextId = ids[i + 1];
        if (element.typ == constants.bpmnNodeType.ExclusiveGateway) {
            nextSteps = element.extraInfo.flows || element.extraInfo.next;
        } else {
            let nextStep;
            if (element.extraInfo != null && element.extraInfo.next != null) {
                nextStep = element.extraInfo.next;
            } else {
                if (noAutoNext == true) continue;
                nextStep = nextId;
            }

            nextSteps = [];
            if (!Array.isArray(nextStep)) nextStep = [nextStep];
            for (let nxtStep of nextStep) {
                let sequenceId;
                if (typeof nxtStep == 'object') {
                    sequenceId = nxtStep.id;
                    nxtStep = nxtStep.target;
                } else {
                    flowNo++;
                    sequenceId = 'sequenceflow_' + flowNo;
                }

                nextSteps.push({ id: sequenceId, target: nxtStep });
            }
        }

        for (let nextStep of nextSteps) {
            if (nextStep == null) continue;
            let sequenceFlow = { typ: 'bpmn:sequenceFlow', sourceRef: id, ...nextStep };
            if (sequenceFlow.target == null) {
                sequenceFlow.target = nextId;
            }
            sequenceFlow.targetRef = sequenceFlow.target;
            delete sequenceFlow.target;
            delete sequenceFlow.type;

            let outElement = elementMap[sequenceFlow.targetRef];
            if (outElement == null) {
                console.error('Invalid nextStep ' + sequenceFlow.targetRef);
                continue;
            }
            let boundsIn = getBounds(element);
            let boundsOut = getBounds(outElement);
            sequenceFlow.diaWayPoints = getArrowPoints(boundsIn, boundsOut, sequenceFlow.targetRef == nextId);
            sequenceFlowMap[sequenceFlow.id] = sequenceFlow;

            outgoing.push(sequenceFlow.id);
            if (outElement['bpmn:incoming'] == null) outElement['bpmn:incoming'] = [];
            outElement['bpmn:incoming'].push(sequenceFlow.id);
        }
        element['bpmn:outgoing'] = outgoing;
    }

    let horizontalLines = [];
    let verticalLines = [];

    for (let sequenceFlow of Object.values(sequenceFlowMap)) {
        let sourceElement = elementMap[sequenceFlow.sourceRef];
        let targetElement = elementMap[sequenceFlow.targetRef];

        let isSourceGateway = sourceElement.typ == constants.bpmnNodeType.ExclusiveGateway;
        let isTargetGateway = targetElement.typ == constants.bpmnNodeType.ExclusiveGateway;

        let points = sequenceFlow.diaWayPoints;
        for (let i = 0; i < points.length - 1; i++) {
            let canMoveStartPoint = i > 0 || isSourceGateway == false;
            let canMoveEndPoint = i < points.length - 2 || isTargetGateway == false;

            let startPoint = points[i];
            let endPoint = points[i + 1];
            if (startPoint.y == endPoint.y) {
                let currLine = { y: startPoint.y, x1: Math.min(startPoint.x, endPoint.x), x2: Math.max(startPoint.x, endPoint.x) };
                let overLap = horizontalLines.length > 0;
                while (overLap) {
                    for (let line of horizontalLines) {
                        if (line.y == currLine.y && (
                            (line.x1 > currLine.x1 && line.x1 < currLine.x2) || (line.x2 > currLine.x1 && line.x1 < currLine.x2) ||
                            (currLine.x1 > line.x1 && currLine.x1 < line.x2) || (currLine.x2 > line.x1 && currLine.x1 < line.x2))) {
                            overLap = true;
                            currLine.y += lineGapY;
                        } else {
                            overLap = false;
                        }
                    }
                }

                if (canMoveStartPoint) startPoint.y = currLine.y;
                if (canMoveEndPoint) endPoint.y = currLine.y;
                horizontalLines.push(currLine);
            }

            if (startPoint.x == endPoint.x) {
                let currLine = { x: startPoint.x, y1: Math.min(startPoint.y, endPoint.y), y2: Math.max(startPoint.y, endPoint.y) };
                let overLap = verticalLines.length > 0;
                while (overLap) {
                    for (let line of verticalLines) {
                        if (line.x == currLine.x && (
                            (line.y1 > currLine.y1 && line.y1 < currLine.y2) || (line.y2 > currLine.y1 && line.y1 < currLine.y2) ||
                            (currLine.y1 > line.y1 && currLine.y1 < line.y2) || (currLine.y2 > line.y1 && currLine.y1 < line.y2))) {
                            overLap = true;
                            currLine.x += 10;
                        } else {
                            overLap = false;
                        }
                    }
                }
                if (canMoveStartPoint) startPoint.x = currLine.x;
                if (canMoveEndPoint) endPoint.x = currLine.x;
                verticalLines.push(currLine);
            }
        }
    }

    let groupMap = {};
    if (doNotRenderGroups !== true) {
        for (let i = 0; i < groupPosArr.length; i++) {
            let grpData = groupPosArr[i];
            let grpBounds = {
                x: grpData.x,
                y: grpData.y,
                width: grpData.width,
                height: grpData.height
            };

            if (i == 0) {
                grpBounds.x += 80;
                grpBounds.width -= 80;
            }

            if (i == groupPosArr.length - 1) {
                grpBounds.width -= 80;
            }

            let groupElement = {
                typ: 'bpmn:group',
                groupLabel: grpData.name,
                diaBounds: grpBounds
            };
            let id = 'grp_' + i;
            groupMap[id] = groupElement;
        }
    }

    for (let element of Object.values(elementMap)) {
        delete element.extraInfo;
    }
    let bpmnObj = { elementMap: { ...elementMap, ...sequenceFlowMap, ...groupMap } };

    let processDef = new processDefinition();
    processDef.elementMap = bpmnObj.elementMap;
    let xmlDoc = processDef.buildXMLDoc();
    let builder = new xml2js.Builder({ xmldec: { version: '1.0', encoding: 'UTF-8' }, renderOpts: { pretty: true, indent: '\t', newline: os.EOL } });
    let xml = builder.buildObject(xmlDoc);
    let externalAttrs = processDef.externalAttrs;

    if (fileName == null) fileName = 'sample.bpmn';

    let saveParams = { fileName, modelType, xml, externalAttrs };
    if (modelType == constants.modelType.Orchestrator) {
        saveParams.folder = config.folders.resources.published.models.orchestrator.bpmn;
    } else {
        saveParams.folder = config.folders.resources.published.models.accelerator.bpmn;
    }

    if (params.save == true) {
        rslt = await bpmnService.saveModel(saveParams);
    }

    return { rc: 0, ...saveParams };
}

module.exports = { generateBPMN };