const path = require('path');
require('../../app/modulesLoader');
const { config, serverSetup, util } = global.modules;

serverSetup.getCredentials().then(async function (rslt) {
    if (rslt.rc != 0) {
        console.log(rslt.msg);
        return;
    }

    rslt = await runProcess();
    console.log('Finished. ' + JSON.stringify(rslt));
    process.exit();
});

async function runProcess() {
    let rslt;
    let folderPath;

    await util.wait(100);

    if (config.app.general_test == null) {
        return { rc: 1, msg: "Provide test file name using attribute 'app.general_test' in your my config" };
    }

    if (config.app.agent_id == null || config.app.agent_id == 'published') {
        folderPath = path.join(config.folders.resources.published.root, 'GeneralTest');
    } else {
        folderPath = path.join(config.folders.resources.private.root, config.app.agent_id, 'GeneralTest');
    }

    try {
        let modulePath = path.resolve(folderPath, config.app.general_test);
        let testModule = require(modulePath);
        rslt = await testModule.process();
    } catch (err) {
        console.log(err.message + '\r\n\r\n' + err.stack);
        rslt = { rc: 1, msg: err.message };
    }
    return rslt;
}