async function process(appDriver, params, log, saveElementMap) {
    //log(JSON.stringify(params));
    //await saveElementMap(appDriver);

    let rslt = await appDriver.setValue({ selector: { controlType: 'Edit' }, value: params, refresh: true });
    if (rslt.rc != 0) return rslt;

    rslt = await appDriver.invoke({ selector: { automationId: 'SubmitButton' } });
    if (rslt.rc != 0) return rslt;

    return { rc: 0 };
}

module.exports = { process };