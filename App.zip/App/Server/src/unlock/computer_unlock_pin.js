const { winAppDriver, util } = global.modules;
const { keyCode } = winAppDriver;

async function process(appDriver, params, log, saveElementMap) {
    // log(JSON.stringify(params));
    // await saveElementMap(appDriver);

    await util.wait(3000);

    let rslt = await appDriver.click({ selector: { name: 'Sign-in options', controlType: 'Hyperlink', automationId: 'SignInOptionsLink' }, atElement: true, refresh: true });
    if (rslt.rc != 0) return rslt;

    await util.wait(3000);

    await saveElementMap(appDriver);

    log(`Found Sign in option rslt: ${rslt.rc}`);

    rslt = await appDriver.findElement({ selector: { controlType: 'Button', name: 'PIN' }, refresh: true });
    if (rslt.rc == 0) {
        rslt = await appDriver.invoke({ selector: { controlType: 'Button', name: 'PIN' }, refresh: true });
        if (rslt.rc != 0) return rslt;
    } else {
        rslt = await appDriver.setValue({ selector: { controlType: 'Edit', name: 'PIN' }, value: params, refresh: true });
        if (rslt.rc != 0) return rslt;
    }

    rslt = await appDriver.sendKey({ key: keyCode.VK_RETURN });
    if (rslt.rc != 0) return rslt;

    return { rc: 0 };
}

module.exports = { process };