const path = require('path');
const fs = require('fs');

global.rootDir = path.join(__dirname, '..').replace(/\\/g, '/') + '/';
global.patchLoaders = [];

const workDir = path.resolve(global.rootDir, '..');
const currentWorkDir = process.cwd();
if (workDir !== currentWorkDir) {
    process.chdir(workDir);
    console.log(`Working directory set to ${process.cwd()}`);
}

function loadModules() {
    const appDbPath = path.join(global.rootDir, 'actionabl.db');

    if (fs.existsSync(appDbPath)) {
        let deployment_api;

        try {
            deployment_api = require(global.rootDir + '/bindings/deployment_api');
        } catch (err) {
            console.error(`Error loading deployment_api: ${err.message}`);
            process.exit(1);
        }

        global.appLoader = getAppLoader(deployment_api, appDbPath);

        const files = fs.readdirSync(global.rootDir);
        files.sort();
        files.reverse();

        for (const fileName of files) {
            if (fileName.startsWith('actionabl_') && fileName.endsWith('.db') && fileName !== 'actionabl.db') {
                let patchLoader = getAppLoader(deployment_api, global.rootDir + fileName);
                patchLoader.fileName = fileName;
                global.patchLoaders.push(patchLoader);
            }
        }

        global.appLoader.BuildFunction({ require, module, name: 'modules' });

    } else {
        require(global.rootDir + '/common/modules');
    }
}

function getAppLoader(deployment_api, appDbPath) {
    const appLoader = new deployment_api.AppLoader();
    appLoader.LoadApp(require, module, appDbPath);
    appLoader.moduleMap = appLoader.ModuleMap();
    return appLoader;
}

loadModules();
