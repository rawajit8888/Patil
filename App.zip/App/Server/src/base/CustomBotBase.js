const { ImplBase } = global.modules;

class CustomBotBase extends ImplBase {
    async init(params) {
        let self = this;
        self.data = params.data || {};
        self.botParams = params.botParams || {};
        return { rc: 0 };
    }

    async process() {
        return { rc: 1, msg: 'process must be implemented' };
    }
}

module.exports = CustomBotBase;