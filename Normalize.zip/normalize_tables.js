const modules = global.modules;
const { util, db, GenericScriptBase, markerService, constants } = modules;

class NormalizeTableScript extends GenericScriptBase {
    async process() {
        let self = this;
        let rslt;
        console.log('night load started.');
        self.attachDuplicate = 0;
        self.procDuplicate = 0; 
        self.contentDuplicate = 0;
        rslt = await self.performNormalize();
        if (rslt.rc != 0) return rslt;
        console.log('Proc Duplicate: ' + self.procDuplicate + ' attach duplicate: ' + self.attachDuplicate + ' content duplicate: ' + self.contentDuplicate);
        console.log('night load over.');
        return { rc: 0 };
    }

    async performNormalize(){
        let self = this;
        let { maxCount} = self.scriptParams;
        let rslt = await self.createTables();
        if (rslt.rc != 0) return rslt;
        let totalCount = 0;
        while (true) {
            rslt = await db.beginTransaction();
            if (rslt.rc != 0) return rslt;
            let dbConn = rslt.data;

            rslt = await markerService.getValue('NormalizedTable-LastUpdateDate');
            if (rslt.rc != 0) return rslt;
            self.lastUpdateDate = rslt.data;

            rslt = await self.normalizeTables(dbConn);
            if (rslt.rc != 0 ) {
                await db.rollback(dbConn);
                return rslt;
            }
            let moveCount = rslt.data;
            let lastRowDateTime = rslt.lastRowDateTime;
            if (rslt.rc == 0) {
                rslt = await db.commit(dbConn);
                } else {
                rslt = await db.rollback(dbConn);
            }
            rslt = await markerService.updateValue('NormalizedTable-LastUpdateDate', lastRowDateTime);
            if (rslt.rc != 0) return rslt;

            
            if (rslt.rc != 0) return rslt;
    
            console.debug(moveCount + ' rows normalized');
            totalCount += moveCount;
            if (moveCount < maxCount) {
                break;
            }
        }
        console.debug('Total ' + totalCount + ' rows normalized');
        return { rc: 0, data: totalCount };
    }

    async normalizeTables(dbConn){
        let self = this;
        let {errorNotificationEmailId, maxCount} = self.scriptParams;
        let notificationInfo = { email_notification: true, recipient_email: errorNotificationEmailId, 
            process_key: self.processKey, task_key: self.taskKey, orig_buss_id: self.data.buss_id };
        let lastUpdateDate = self.lastUpdateDate;
        let rslt = await db.retrieve(`Select * From rt_proc_inst where 
                 updated_at >  '${lastUpdateDate}' Order By updated_at fetch first  ${maxCount} rows only`, null, dbConn );
        if (rslt.rc != 0) return rslt;

        let procRows = rslt.data;
        util.decryptDataRows(procRows, 'proc_data');
        let lastRowDateTime = self.lastUpdateDate;
        for (let procRow of procRows) {
            if (procRow.proc_data && procRow.proc_data.attachment_types) {
                procRow.attachment_types = procRow.proc_data.attachment_types;
            }
            procRow.subject = procRow.proc_data.subject;
            procRow.sender = procRow.proc_data.sender;
            procRow.request_type = procRow.proc_data.request_type;
            procRow.processing_department = procRow.proc_data.processing_department;
            procRow.new_header = procRow.proc_data.new_header;
            procRow.header_error = procRow.proc_data.header_error;
            procRow.detail_error = procRow.proc_data.detail_error;
            procRow.upload_error = procRow.proc_data.upload_error;
            procRow.new_detail = procRow.proc_data.new_detail;
            procRow.received_date = procRow.proc_data.received_date;
            rslt = await db.del('nrt_proc_inst', { id: procRow.id }, dbConn);
            if (rslt.rc != 0) return rslt;
            //hardcoded for error
            //procRow.id = null;
            rslt = await db.insert('nrt_proc_inst', procRow, dbConn);
            if (rslt.rc != 0) {
                if (rslt.err && rslt.err.code == '23505') {
                    self.procDuplicate++;
                    console.error('Duplicate proc id ' + procRow.id)
                } else {
                    console.error(this.processKey + " : " + rslt.msg);
                    if (rslt.err != null && rslt.err.detail != null) console.error(rslt.err.detail);
                    notificationInfo.error_message  = 'Error while inserting row with business id ' + procRow.buss_id + '.';
                    notificationInfo.error_message += ' \n ' + rslt.msg;
                    let rsltTemp = await self.sendNotification(notificationInfo);
                    return rslt;
                }
            }

            rslt = await db.del('nrt_proc_inst_attachment', { proc_id: procRow.id }, dbConn);
            if (rslt.rc != 0) return rslt;
            if (procRow.proc_data.headers && procRow.proc_data.headers.length > 0) {
                for (let header of procRow.proc_data.headers) {
                    if (!header.attachment_name) continue;
                    if (header.output_type == 'NU') {
                        header.record_count = header.nu_count;
                        header.file_name = header.nu_file_name;
                    }
                    else if (header.output_type == 'DU') {
                        header.record_count = header.du_count;
                        header.file_name = header.du_file_name;
                    }
                    else if (header.output_type == 'NW') {
                        header.record_count = header.nw_count;
                        header.file_name = header.nw_file_name;
                    }
                    if (header.total_salary) header.total_salary = parseInt(header.total_salary);
                    if (header.total_salary = 'NaN') header.total_salary = 0;
                    header.proc_id = procRow.id;
                    header.proc_attachment_sheet = procRow.id + '-' + header.header_location;
                    delete header.du_count;
                    delete header.nu_count;
                    delete header.nw_count;
                    delete header.du_file_name;
                    delete header.nu_file_name;
                    delete header.nw_file_name;
                    delete header.ufe_message;
                    delete header.csle_error;
                    rslt = await db.insert('nrt_proc_inst_attachment', header, dbConn);
                    if (rslt.rc != 0) {
                        if (rslt.err && rslt.err.code == '23505') {
                            self.attachDuplicate++;
                            console.error('Duplicate attachment name ' + header.attachment_name)
                        } else {
                            console.error(this.processKey + " : " + rslt.msg);
                            if (rslt.err != null && rslt.err.detail != null) console.error(rslt.err.detail);
                            notificationInfo.error_message  = 'Error while inserting row with business id ' + procRow.buss_id + '.';
                            notificationInfo.error_message += ' \n ' + rslt.msg;
                            let rsltTemp = await self.sendNotification(notificationInfo);
                            return rslt;
                        }
                    }
                }
            }
            rslt = await db.retrieve(`Select * From rt_content where proc_id =  ${procRow.id} `, null, dbConn);
            if (rslt.rc != 0) return rslt;
            util.decryptDataRows(rslt.data, 'content_info');
            let contentRows = rslt.data;
            rslt = await db.del('nrt_content', { proc_id: procRow.id }, dbConn);
            if (rslt.rc != 0) return rslt;
            for (let contentRow of contentRows) {
                delete contentRow.name;
                delete contentRow.file_id;
                delete contentRow.task_level;
                delete contentRow.tblRowControl;
                //delete contentRow.content_info;
                if (contentRow.content_info && contentRow.content_info.file_type) contentRow.file_type = contentRow.content_info.file_type;
                util.encryptData(contentRow, 'content_info');
                rslt = await db.insert('nrt_content', contentRow, dbConn);
                if (rslt.rc != 0) {
                    if (rslt.err && rslt.err.code == '23505') {
                        self.contentDuplicate++;
                        console.error('Duplicate content id ' + contentRow.id)
                    } else {
                        console.error(this.processKey + " : " + rslt.msg);
                        if (rslt.err != null && rslt.err.detail != null) console.error(rslt.err.detail);
                        notificationInfo.error_message  = 'Error while inserting row with business id ' + procRow.buss_id + '.';
                        notificationInfo.error_message += ' \n ' + rslt.msg;
                        let rsltTemp = await self.sendNotification(notificationInfo);
                        return rslt;
                    }
                }
            }
            lastRowDateTime = procRow.updated_at;
        }
        return { rc: 0, data: procRows.length, lastRowDateTime: lastRowDateTime };
    }

    async createTables() {
        const ddl = [
            `Create Table If Not Exists nrt_content (
                    id serial Primary Key,
                    proc_id integer Not Null,
                    task_id integer,
                    name varchar(64),
                    type integer Not Null,
                    category integer Not Null,
                    access_level integer Not Null,
                    content_info bytea,
                    file_type varchar(256),
                    updated_at timestamp Not Null,
                    updated_by varchar(64)
                )`,
            `Create Table If Not Exists nrt_proc_inst (
                    id serial Primary Key,
                    external_id varchar(64),
                    proc_def_key varchar(64) Not Null,
                    buss_id varchar(32) Not Null,
                    status char(1) Not Null,
                    stage varchar(32) Not Null,
                    due_date timestamp,
                    proc_data json,
                    subject varchar,
                    sender varchar(256),
                    request_type varchar(50),
                    processing_department varchar(150),
                    new_detail boolean,
                    new_header boolean,
                    header_error boolean,
                    detail_error boolean,
                    upload_error boolean,
                    error_data json,
                    active boolean,
                    received_date bigint,
                    created_at timestamp Not Null,
                    completed_at timestamp,
                    updated_at timestamp Not Null,
                    updated_by varchar(64) Not Null,
                    attachment_types varchar(256)
                )`,
            `create Table If Not Exists nrt_proc_inst_attachment(
                    id serial Primary KEY,
                    proc_attachment_sheet varchar(255),
                    attachment_name varchar,
                    proc_id serial,
                    layout json,
                    header_location varchar(255),
                    company_name varchar(2550),
                    mol_number varchar(50),
                    salary_month varchar(10),
                    total_salary integer,
                    output_type varchar(2),
                    status varchar,
                    error_message varchar(2550),
                    skip_yom boolean,
                    discard boolean,
                    re_parse boolean,
                    mpn varchar,
                    file_name varchar(255),
                    record_count integer,
                    error_rows json[]
                );`
        ];
        for (let i = 0; i < ddl.length; i++) {
            let sql = ddl[i];
            let rslt = await db.query(sql);
            if (rslt.rc != 0) {
                console.error('Error ' + rslt.msg + os.EOL + sql);
                return rslt;
            }
        }
        return { rc: 0 };
    }

}

module.exports = NormalizeTableScript;

