const modules = global.modules;
const { util, db, GenericScriptBase, markerService, constants } = modules;

class NormalizeTableArchiveScript extends GenericScriptBase {
    async process() {
        let self = this;
        let params = self.scriptParams;
        let rslt;
        console.log('Normalized Tables Archive process started.');
        rslt = await markerService.getTime('NormalizedTableArchive-LastUpdateDate');
        if (rslt.rc != 0) return rslt;
        rslt = await self.performArchive(params);    
        rslt = await markerService.updateTime('NormalizedTableArchive-LastUpdateDate');
        if (rslt.rc != 0) return rslt;
        console.log('Normalized table archive process ended.' );
        return { rc: 0 };
    }

    async performArchive(params) {
        let self = this;
        let archiveDb = db.getArchiveDb();
        let rslt;
        let totalCount = 0;
        params = self.normalize(params);
        let { maxCount } = params;
        while (true) {
            rslt = await db.beginTransaction();
            if (rslt.rc != 0) return rslt;
            let dbConn = rslt.data;
    
            rslt = await archiveDb.beginTransaction();
            if (rslt.rc != 0) return rslt;
            let archiveDbConn = rslt.data;

            rslt = await self.createTables(archiveDb, archiveDbConn);
            if (rslt.rc != 0) return rslt;
   
            if (params.min_age){
                let dt = new Date();
                let archiveDt = new Date(dt.getFullYear(), dt.getMonth(), dt.getDate());
                archiveDt.setDate(archiveDt.getDate() - params.min_age);
                params.created_to = archiveDt;
            }

            rslt = await self.moveData(db, archiveDb, dbConn, archiveDbConn, params);
            if (rslt.rc != 0 || params.count_check == true) {
                await db.rollback(dbConn);
                await archiveDb.rollback(archiveDbConn);
                return rslt;
            }
    
            let moveCount = rslt.data;
    
            if (rslt.rc == 0) {
                rslt = await db.commit(dbConn);
                rslt = await archiveDb.commit(archiveDbConn);
                } else {
                rslt = await db.rollback(dbConn);
                rslt = await archiveDb.rollback(archiveDbConn);
            }
            if (rslt.rc != 0) return rslt;
    
            console.log(moveCount + ' rows archived');
            totalCount += moveCount;
            if (moveCount < maxCount) {
                break;
            }
        }
    
        console.log('Total ' + totalCount + ' rows archived');
    
        return { rc: 0, data: totalCount };
    }

    async moveData(srcDb, destDb, srcConn, destConn, params) {
        let rslt;
    
        let { maxCount, count_check, proc_def_key, status, created_from, created_to, completed_from, completed_to } = params;

        let procWhere = '', delSql, procQueryParams = [], queryParams = [];
    
        if (proc_def_key != null) {
            procQueryParams.push(proc_def_key);
            procWhere += ' And proc_def_key = $' + procQueryParams.length;
        }
        if (status != null ) {
            if (Array.isArray(status)) {
                procWhere += " And status In ('" + status.join("','") + "')";
            } else {
                procQueryParams.push(status);
                procWhere += ' And status = $' + procQueryParams.length;
            }
        }
    
        if (created_from != null) {
            procQueryParams.push(new Date(created_from));
            procWhere += ' And created_at >= $' + procQueryParams.length;
        }
        if (created_to != null) {
            procQueryParams.push(new Date(created_to));
            procWhere += ' And created_at <= $' + procQueryParams.length;
        }
    
        if (completed_from != null) {
            procQueryParams.push(new Date(completed_from));
            procWhere += ' And completed_at >= $' + procQueryParams.length;
        }
        if (completed_to != null) {
            procQueryParams.push(new Date(completed_to));
            procWhere += ' And completed_at <= $' + procQueryParams.length;
        }
    
        procWhere = procWhere.replace('And', 'Where');
    
        let procSelect;
        if (count_check == true) {
            procSelect = 'Select count(*) From nrt_proc_inst' + procWhere;
        } else {
            procSelect = 'Select id, external_id, proc_def_key, buss_id, status, stage, due_date, proc_data, error_data, \
            subject, sender, request_type, processing_department, new_detail, new_header, header_error, detail_error, upload_error, \
            active, received_date, created_at, completed_at, updated_at, updated_by, attachment_types From nrt_proc_inst' + procWhere +  ' fetch first ' + maxCount + ' rows only';
        }
        rslt = await srcDb.retrieve(procSelect, procQueryParams, srcConn);
        if (rslt.rc != 0) return rslt;
        let procRows = rslt.data;
    
        if (count_check == true) {
            return { rc: 0, data: procRows[0].count };
        }
    
        let procInsert = `Insert Into nrt_proc_inst(id, external_id, proc_def_key, buss_id, status, stage, due_date, proc_data, error_data, 
            subject, sender, request_type, processing_department, new_detail, new_header, header_error, detail_error, upload_error, 
            active, received_date, created_at, completed_at, updated_at, updated_by, attachment_types)
            Values($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25)`;
    
        for (let procRow of procRows) {
            /**    nrt_proc_inst    */
            queryParams = [];
            queryParams.push(procRow.id);
            queryParams.push(procRow.external_id);
            queryParams.push(procRow.proc_def_key);
            queryParams.push(procRow.buss_id);
            queryParams.push(procRow.status);
            queryParams.push(procRow.stage);
            queryParams.push(procRow.due_date);
            queryParams.push(procRow.proc_data);
            queryParams.push(procRow.error_data);
            queryParams.push(procRow.subject);
            queryParams.push(procRow.sender);
            queryParams.push(procRow.request_type);
            queryParams.push(procRow.processing_department);
            queryParams.push(procRow.new_detail);
            queryParams.push(procRow.new_header);
            queryParams.push(procRow.header_error);
            queryParams.push(procRow.detail_error);
            queryParams.push(procRow.upload_error);
            queryParams.push(procRow.active);
            queryParams.push(procRow.received_date);
            queryParams.push(procRow.created_at);
            queryParams.push(procRow.completed_at);
            queryParams.push(procRow.updated_at);
            queryParams.push(procRow.updated_by);
            queryParams.push(procRow.attachment_type);

            rslt = await destDb.del('nrt_proc_inst', { id: procRow.id }, destConn);
            if (rslt.rc != 0) return rslt;
            rslt = await destDb.del('nrt_proc_inst_attachment', { proc_id: procRow.id }, destConn);
            if (rslt.rc != 0) return rslt;
            rslt = await destDb.del('nrt_content', { proc_id: procRow.id }, destConn);
            if (rslt.rc != 0) return rslt;
    
            rslt = await destDb.query(procInsert, queryParams, destConn);
            if (rslt.rc != 0) {
                console.error(this.processKey + " : " + rslt.msg);
                if (rslt.err != null && rslt.err.detail != null) console.error(rslt.err.detail);
                console.error('Error while inserting row with business id ' + procRow.buss_id + '.');
                return rslt;
            }
            /**    nrt_proc_inst_attachment    */
    
            let attachmentSelect = `Select proc_attachment_sheet, attachment_name, proc_id, layout, header_location, 
            company_name, mol_number, salary_month, total_salary, output_type, status, error_message, skip_yom, discard, 
            re_parse, mpn, file_name, record_count, error_rows
                From nrt_proc_inst_attachment Where proc_id = $1`;
            rslt = await srcDb.retrieve(attachmentSelect, [procRow.id], srcConn);
            if (rslt.rc != 0) return rslt;
            let attachmentRows = rslt.data;
    
            let attachmentInsert = `Insert Into nrt_proc_inst_attachment(proc_attachment_sheet, attachment_name, proc_id, 
                layout, header_location, company_name, mol_number, salary_month, total_salary, output_type, status, 
                error_message, skip_yom, discard, re_parse, mpn, file_name, record_count, error_rows)
                Values($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19)`;
    
            for (let attachmentRow of attachmentRows) {
                queryParams = [];
                queryParams.push(attachmentRow.proc_attachment_sheet);
                queryParams.push(attachmentRow.attachment_name);
                queryParams.push(attachmentRow.proc_id);
                queryParams.push(attachmentRow.layout);
                queryParams.push(attachmentRow.header_location);
                queryParams.push(attachmentRow.company_name);
                queryParams.push(attachmentRow.mol_no);
                queryParams.push(attachmentRow.salary_month);
                queryParams.push(attachmentRow.total_salary);
                queryParams.push(attachmentRow.output_type);
                queryParams.push(attachmentRow.status);
                queryParams.push(attachmentRow.error_message);
                queryParams.push(attachmentRow.skip_yom);
                queryParams.push(attachmentRow.discard);
                queryParams.push(attachmentRow.re_parse);
                queryParams.push(attachmentRow.mpn);
                queryParams.push(attachmentRow.file_name);
                queryParams.push(attachmentRow.record_count);
                queryParams.push(attachmentRow.error_rows);
    
                rslt = await destDb.query(attachmentInsert, queryParams, destConn);
                if (rslt.rc != 0) {
                    console.error(this.processKey + " : " + rslt.msg);
                    if (rslt.err != null && rslt.err.detail != null) console.error(rslt.err.detail);
                    console.error('Error while inserting row with business id ' + procRow.buss_id + '.');
                    return rslt;
                }
    
            }
    
            delSql = `Delete From nrt_proc_inst_attachment Where proc_id = $1`;
            rslt = await srcDb.query(delSql, [procRow.id], srcConn);
            if (rslt.rc != 0) return rslt;
    
            /**    nrt_content    */
    
            let contentSelect, contentInsert;
            contentSelect = `Select id, proc_id, task_id, name, type, category, access_level, content_info, file_type, updated_at, updated_by From nrt_content Where proc_id = $1`;
            contentInsert = `Insert Into nrt_content(id, proc_id, task_id, name, type, category, access_level, content_info, file_type, updated_at, updated_by)
            Values($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`;
    
            rslt = await srcDb.retrieve(contentSelect, [procRow.id], srcConn);
            if (rslt.rc != 0) return rslt;
            let contentRows = rslt.data;
    
            for (let contentRow of contentRows) {
                queryParams = [];
                queryParams.push(contentRow.id);
                queryParams.push(contentRow.proc_id);
                queryParams.push(contentRow.task_id);
                queryParams.push(contentRow.name);
                queryParams.push(contentRow.type);
                queryParams.push(contentRow.category);
                queryParams.push(contentRow.access_level);
                queryParams.push(contentRow.content_info);
                queryParams.push(contentRow.file_type);
                queryParams.push(contentRow.updated_at);
                if (contentRow.updated_by) {
                    queryParams.push(contentRow.updated_by);
                } else {
                    queryParams.push(constants.user.actionabl);
                }
                rslt = await destDb.query(contentInsert, queryParams, destConn);
                if (rslt.rc != 0) {
                    console.error(this.processKey + " : " + rslt.msg);
                    if (rslt.err != null && rslt.err.detail != null) console.error(rslt.err.detail);
                    console.error('Error while inserting row with business id ' + procRow.buss_id + '.');
                    return rslt;
                }
    
            }
    
            delSql = `Delete From nrt_content Where proc_id = $1`;
            rslt = await srcDb.query(delSql, [procRow.id], srcConn);
            if (rslt.rc != 0) return rslt;
    
            delSql = 'Delete From nrt_proc_inst Where id = $1';
            rslt = await srcDb.query(delSql, [procRow.id], srcConn);
            if (rslt.rc != 0) return rslt;
        }
    
        return { rc: 0, data: procRows.length };
    }
    

    async createTables(archiveDb, archiveDbConn) {
        const ddl = [
            `Create Table If Not Exists nrt_content (
                id serial Primary Key,
                proc_id integer Not Null,
                task_id integer,
                name varchar(64),
                type integer Not Null,
                category integer Not Null,
                access_level integer Not Null,
                content_info bytea,
                file_type varchar(256),
                updated_at timestamp Not Null,
                updated_by varchar(64)
            )`,
            `Create Table If Not Exists nrt_proc_inst (
                    id serial Primary Key,
                    external_id varchar(64),
                    proc_def_key varchar(64) Not Null,
                    buss_id varchar(32) Not Null,
                    status char(1) Not Null,
                    stage varchar(32) Not Null,
                    due_date timestamp,
                    proc_data json,
                    subject varchar,
                    sender varchar(256),
                    request_type varchar(50),
                    processing_department varchar(150),
                    new_detail boolean,
                    new_header boolean,
                    header_error boolean,
                    detail_error boolean,
                    upload_error boolean,
                    error_data json,
                    active boolean,
                    received_date bigint,
                    created_at timestamp Not Null,
                    completed_at timestamp,
                    updated_at timestamp Not Null,
                    updated_by varchar(64) Not Null,
                    attachment_types varchar(256)
                )`,
            `create Table If Not Exists nrt_proc_inst_attachment(
                    proc_attachment_sheet varchar(255) Primary Key,
                    attachment_name varchar,
                    proc_id serial,
                    layout json,
                    header_location varchar(255),
                    company_name varchar(2550),
                    mol_number varchar(50),
                    salary_month varchar(10),
                    total_salary integer,
                    output_type varchar(2),
                    status varchar,
                    error_message varchar(2550),
                    skip_yom boolean,
                    discard boolean,
                    re_parse boolean,
                    mpn varchar,
                    file_name varchar(255),
                    record_count integer,
                    error_rows json[]
                );`
        ];
        for (let i = 0; i < ddl.length; i++) {
            let sql = ddl[i];
            let rslt = await archiveDb.query(sql, null, archiveDbConn);
            if (rslt.rc != 0) {
                console.error('Error ' + rslt.msg + os.EOL + sql);
                return rslt;
            }
        }
        return { rc: 0 };
    }


    normalize(params){
        Object.entries(params).forEach((entry) => {
            const [key, value] = entry;
            if (typeof value != 'string' && typeof value != 'int' && typeof value != 'date'
            && typeof value == 'object' && Object.keys(value).length == 0) params[key] = null;
          });      
          return params;  
    }

}

module.exports = NormalizeTableArchiveScript;

